#ifndef _MAIN_H_
#define _MAIN_H_

#include "threadmgr_if.h"

/*
 * Constant define
 */


/*
 * Type define
 */


/*
 * External
 */
extern threadmgr_external_if_t *gp_if;


#endif
