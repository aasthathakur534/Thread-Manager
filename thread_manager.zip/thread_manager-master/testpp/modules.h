#ifndef _MODULES_H_
#define _MODULES_H_

enum class module : int {
	module_a = 0,
	module_b,
	module_c,

	module_max
};

#endif
